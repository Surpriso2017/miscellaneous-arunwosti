import 'package:http_service/model/video/large.dart';

class Resolution{
  Large large;
  Medium medium;
  Small small;
  Tiny tiny;


  Resolution({
    required this.large,
    required this.medium,
    required this.small,
    required this.tiny
  });


  factory Resolution.fromjason(Map json){
    return Resolution
    (
      large: Large.fromjson(json['large']), 
      medium: Medium.fromjson(json['large']), 
      small: Small.fromjson(json['large']), 
      tiny: Tiny.fromjson(json['large'])
      );
  }
}