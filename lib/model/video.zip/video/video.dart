import 'package:http_service/model/video/hits.dart';

class Video{
  int total;
  int totalhits;
  Hit hits;

  Video({
    required this.total,
    required this.totalhits,
    required this.hits
  });

  factory Video.convertFromJson(Map json){
    return Video(
      total: json['total'], 
      totalhits: json['totalhits'], 
      hits: Hit.fromjson(json['hits'])
      );
  }
}